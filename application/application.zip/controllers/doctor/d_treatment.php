<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class D_treatment extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(['Diagnose_Model','Identity_Model','Treatment_Model']);
	}
    
    function index(){
        $id = $this->uri->segment(3);
        $data=array(
            'dataPatient'=>$this->Identity_Model->getAllIdentity(),
            'line'=>$this->Identity_Model->getIdentityById($id)->row_array()
        );
        $this->load->view('doctor/v_treatment', $data);
    }

    function result() 
    {
        $data =array('dataTreatment'=>$this->Treatment_Model->getAllTreatment());
        $this->load->view('doctor/v_result',$data);
    }

    function detailResult()
    {
        $id = $this->uri->segment(3);
        $data=array('dataTreatment'=>$this->Treatment_Model->getAllTreatment(),
                    'record'=>$this->Treatment_Model->getTreatmentInfo(),
                    'detail'=>$this->Treatment_Model->getDTreatmentById($id)
        );
        $this->load->view('doctor/v_result_detail',$data);
    }   

    function resultTreatment() 
    {
        $data =array('relasi'=>$this->Treatment_Model->getPatient());
        $this->load->view('doctor/v_treatment_result',$data);
    }
 
    function addResult(){

        $data=  ['Pat_NIK'=>$this->input->post('Pat_NIK'),
			    'Treat_Coming_Date'=>$this->input->post('Treat_Coming_Date'),
			    'Diag_APRI'=>$this->input->post('Diag_APRI'),
                'Treat_Next_Date'=>$this->input->post('Treat_Next_Date'),
                'Treat_Next_Therapy'=>$this->input->post('Treat_Next_Therapy')];
        $this->Treatment_Model->insertResult($data);
        redirect('doctor/d_treatment/result');
    }

}
