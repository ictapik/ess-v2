<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Identity extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model('Identity_Model');
	}
    
    function index(){
        $id = $this->uri->segment(3);
        $data=array(
            'dataIdentity'=>$this->Identity_Model->getAllIdentity(),
            'line'=>$this->Identity_Model->getIdentityById($id)->row_array()
        );
        $this->load->view('v_identity', $data);
    }
 
    function addIdentity(){

        $data=  ['Pat_ID'=>$this->input->post('Pat_ID'),
			    'Pat_NIK'=>$this->input->post('Pat_NIK'),
			    'Pat_Name'=>$this->input->post('Pat_Name'),
                'Pat_Incoming'=>$this->input->post('Pat_Incoming'),
                'Pat_Doctor'=>$this->input->post('Pat_Doctor'),
                'Pat_Gender'=>$this->input->post('Pat_Gender'),
                'Pat_Date_Of_Birth'=>$this->input->post('Pat_Date_Of_Birth'),
                'Pat_Mom_Name'=>$this->input->post('Pat_Mom_Name'),
                'Pat_Marital_Stat'=>$this->input->post('Pat_Marital_Stat'),
                'Pat_Education'=>$this->input->post('Pat_Education'),
                'Pat_Jobs'=>$this->input->post('Pat_Jobs'),
                'Pat_Address'=>$this->input->post('Pat_Address'),
                'Pat_Phone'=>$this->input->post('Pat_Phone'),
                'Pat_Risk'=>$this->input->post('Pat_Risk'),
                'Pat_PMO_Name'=>$this->input->post('Pat_PMO_Name'),
                'Pat_PMO_Address'=>$this->input->post('Pat_PMO_Address'),
                'Pat_PMO_Phone'=>$this->input->post('Pat_PMO_Phone'),
                'Pat_PMO_Status'=>$this->input->post('Pat_PMO_Status')];
        $this->Identity_Model->insertIdentity($data);
        redirect('identity');
    }
}
