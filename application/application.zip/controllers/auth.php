<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('Login_Model');
	}

	function index()
	{
		$this->load->view('v_login');
	}

	function login(){
        $username       = htmlspecialchars($this->input->post('User_Uname',TRUE),ENT_QUOTES);
        $password       = htmlspecialchars($this->input->post('User_Pwd',TRUE),ENT_QUOTES);
        $cek_admin      = $this->Login_Model->auth($username,$password);
 
        if($cek_admin->num_rows() > 0){ //jika login sebagai admin
                $data = $cek_admin->row_array();
                $this->session->set_userdata('masuk',TRUE);
                 if($data['User_Lvl']=='Doctor'){ //Akses admin
                    $this->session->set_userdata('akses','1');
                    $this->session->set_userdata('ses_id',$data['User_ID']);
                    $this->session->set_userdata('ses_nama',$data['User_Name']);
                    redirect('doctor/d_dashboard');
 
                 }else{ //akses admin
                    $this->session->set_userdata('akses','2');
                    $this->session->set_userdata('ses_id',$data['User_ID']);
                    $this->session->set_userdata('ses_nama',$data['User_Name']);
                    redirect('perawat/p_dashboard');
                 }
 
        }else{ //jika login sebagai user
                    $cek_member=$this->Login_Model->auth_member($username,$password);
                    if($cek_member->num_rows() > 0){
                            $data=$Login_Model->row_array();
                    $this->session->set_userdata('masuk',TRUE);
                            $this->session->set_userdata('akses','3');
                            $this->session->set_userdata('ses_id',$data['kd_user']);
                            $this->session->set_userdata('ses_nama',$data['User_Name']);
                            redirect('dashboard');
                    }else{  // jika username dan password tidak ditemukan atau salah
                            echo $this->session->set_flashdata("pesan", "<div class=\"col-md-12\"><div class=\"alert alert-danger\" id=\"alert\">Username atau Password salah !!</div></div>");
                            $url=base_url('auth');
                            redirect($url);
                    }
        }
 
    }
 
    function logout(){
        $this->session->sess_destroy();
        $url=base_url('auth');
        redirect($url);
    }
}
