<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Diagnose extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(['Diagnose_Model','Identity_Model']);
	}
    
    function index(){
        $id = $this->uri->segment(3);
        $data=array(
            'dataDiagnose'=>$this->Diagnose_Model->getAllDiagnose(),
            'dataPatient'=>$this->Identity_Model->getAllIdentity(),
            'line'=>$this->Diagnose_Model->getDiagnoseById($id)->row_array()
        );
        $this->load->view('v_diagnose', $data);
    }

    function history(){
        $id = $this->uri->segment(3);
        $data=array(
            'dataDiagnose'=>$this->Diagnose_Model->getAllDiagnose(),
            'dataPatient'=>$this->Identity_Model->getAllIdentity(),
            'line'=>$this->Diagnose_Model->getDiagnoseById($id)->row_array()
        );
        $this->load->view('v_history', $data);
    }

    function addHistory(){
        $data=  ['His_Hepa'=>$this->input->post('His_Hepa'),
                'Pat_NIK'=>$this->input->post('Pat_NIK'),
                'His_Hcv'=>$this->input->post('His_Hcv'),
                'His_Treat_Hepa'=>$this->input->post('His_Treat_Hepa')];
        $this->Diagnose_Model->insertHistory($data);
        redirect('diagnose');
    }
 
    function addDiagnose(){
        $data=  ['Diag_Date'=>$this->input->post('Diag_Date'),
			    'Pat_NIK'=>$this->input->post('Pat_NIK'),
			    'Diag_Hemoglobin'=>$this->input->post('Diag_Hemoglobin'),
                'Diag_Trombosit'=>$this->input->post('Diag_Trombosit'),
                'Diag_Albumin'=>$this->input->post('Diag_Albumin'),
                'Diag_Leukosit'=>$this->input->post('Diag_Leukosit'),
                'Diag_Bilirubin'=>$this->input->post('Diag_Bilirubin'),
                'Diag_INR'=>$this->input->post('Diag_INR'),
                'Diag_SGPT'=>$this->input->post('Diag_SGPT'),
                'Diag_SGOT'=>$this->input->post('Diag_SGOT'),
                'Diag_Ureum'=>$this->input->post('Diag_Ureum'),
                'Diag_Kreatinin'=>$this->input->post('Diag_Kreatinin'),
                'Diag_APRI'=>$this->input->post('Diag_APRI')];
        $this->Diagnose_Model->insertDiagnose($data);
        redirect('diagnose');
    }
}
