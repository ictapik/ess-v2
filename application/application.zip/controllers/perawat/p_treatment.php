<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class P_treatment extends CI_Controller {
	function __construct(){
        parent::__construct();
        $this->load->model(['Diagnose_Model','Identity_Model','Treatment_Model']);
	}
    
    function index(){
        $id = $this->uri->segment(3);
        $data=array(
            'dataPatient'=>$this->Identity_Model->getAllIdentity(),
            'line'=>$this->Identity_Model->getIdentityById($id)->row_array()
        );
        $this->load->view('perawat/v_treatment', $data);
    }

    function nextTreatment(){
        $id = $this->uri->segment(3);
        $data=array(
            'dataPatient'=>$this->Treatment_Model->getHalfPatient(),
            'line'=>$this->Identity_Model->getIdentityById($id)->row_array()
        );
        $this->load->view('perawat/v_next_treatment', $data);
    }

    function nextTreatmentResult() 
    {
        $data =array('record'=>$this->Treatment_Model->getTreatmentInfo());
        $this->load->view('perawat/v_next_treatment_detail',$data);
    }
 
    function addDetail(){
    $data=  ['Pat_NIK'=>$this->input->post('Pat_NIK'),
            'Com_Count'=>$this->input->post('Com_Count'),
            'Com_Date'=>$this->input->post('Com_Date'),
            'Com_Left_Medicine'=>$this->input->post('Com_Left_Medicine'),
            'Com_Effect_Medicine'=>$this->input->post('Com_Effect_Medicine'),
            'Com_Next_Date'=>$this->input->post('Com_Next_Date')];
        $this->Treatment_Model->insertDetail($data);
        redirect('perawat/p_treatment/nextTreatment');
    }

}
