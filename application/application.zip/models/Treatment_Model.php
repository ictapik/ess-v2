<?php
class Treatment_Model extends CI_Model{
 
    //  Function Get All Data
    function getAllTreatment(){
        return $this->db->get('treatment')->result();
    }

    function view_patient(){
        return $this->db->get('patient');
    }

    function getRelasi(){
        return $this->db->query("SELECT * FROM patient as p, diagnose as d WHERE p.Pat_NIK=d.Pat_NIK")->result();
    }

    function getHalfPatient(){
        return $this->db->query("SELECT * FROM patient as p, diagnose as d, history as h, treatment as t, diagnose_hcv as dh, detail_coming as dc WHERE dc.Pat_NIK=p.Pat_NIK AND dc.Pat_NIK=d.Pat_NIK AND dc.Pat_NIK=h.Pat_NIK AND dc.Pat_NIK=t.Pat_NIK AND dc.Pat_NIK=dh.Pat_NIK")->result();
    }

    function getPatient(){
        if(isset($_GET['Pat_NIK'])) {
            $patient = $_GET['Pat_NIK'];
        } else {
            $patient = 'null';
        }
        $this->db->select('*');
        $this->db->from('diagnose as d');
        $this->db->from('patient as p');
        $this->db->where('d.Pat_NIK = ', ''.$patient.'');
        $this->db->where('p.Pat_NIK = ', ''.$patient.'');
        $this->db->limit('1');
        $query = $this->db->get();
        if($query->num_rows() > 0) {
            $out = $query->result();
            return $out;
        } else {
            return array();
        }
    }

    function getTreatmentInfo(){
        if(isset($_GET['Pat_NIK'])) {
            $patient = $_GET['Pat_NIK'];
        } else {
            $patient = 'null';
        }
        $this->db->select('*');
        $this->db->from('diagnose as d');
        $this->db->from('patient as p');
        $this->db->from('history as h');
        $this->db->from('treatment as t');
        $this->db->from('diagnose_hcv as dh');
        $this->db->where('d.Pat_NIK = ', ''.$patient.'');
        $this->db->where('p.Pat_NIK = ', ''.$patient.'');
        $this->db->where('h.Pat_NIK = ', ''.$patient.'');
        $this->db->where('t.Pat_NIK = ', ''.$patient.'');
        $this->db->where('dh.Pat_NIK = ', ''.$patient.'');
        $this->db->limit('1');
        $query = $this->db->get();
        if($query->num_rows() > 0) {
            $out = $query->result();
            return $out;
        } else {
            return array();
        }
    }

    //  Function Get Data By ID
    function getTreatmentById($id){
        $data = array('Pat_NIK'=>$id);
        return $this->db->get_where('treatment',$data);
    }
    function getPatientById($id){
        $param = array('Pat_NIK'=>$id);
        return $this->db->get_where('patient',$param);
    }
    function getDTreatmentById($id){
        $this->db->select('*');
        $this->db->from('treatment');
        $this->db->where('Pat_NIK', $id);
        $query = $this->db->get();
        if($query->num_rows()>0){
            $out = $query->result();
            return $out;
        } else {
            return FALSE;
        }
    }


    function view_data($id){
        $this->db->join('patient', "patient.Pat_NIK=diagnose.Pat_NIK");
        return $this->db->get_where('diagnose', "diagnose.Pat_NIK='$id'");
    }

    //  Function Insert Data
    function insertTreatment($data){
        return $this->db->insert('diagnose',$data);
    }
    function insertResult($data){
        return $this->db->insert('treatment',$data);
    }
    function insertDetail($data){
        return $this->db->insert('detail_coming',$data);
    }
     
}