<?php
class Identity_Model extends CI_Model{
 
    //  Function Get All Data
    function getAllIdentity(){
        return $this->db->get('patient')->result();
    }

    //  Function Get Data By ID
    function getIdentityById($id){
        $data = array('Pat_ID'=>$id);
        return $this->db->get_where('patient',$data);
    }

    //  Function Insert Data
    function insertIdentity($data){
        return $this->db->insert('patient',$data);
    }
}