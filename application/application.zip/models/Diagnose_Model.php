<?php
class Diagnose_Model extends CI_Model{
 
    //  Function Get All Data
    function getAllDiagnose(){
        return $this->db->get('diagnose')->result();
    }

    //  Function Get Data By ID
    function getDiagnoseById($id){
        $data = array('Diag_ID'=>$id);
        return $this->db->get_where('diagnose',$data);
    }

    //  Function Insert Data
    function insertDiagnose($data){
        return $this->db->insert('diagnose',$data);
    }
    function insertHepa($data){
        return $this->db->insert('diagnose_hcv',$data);
    }
    function insertHistory($data){
        return $this->db->insert('history',$data);
    }
     
}