<?php
class Login_Model extends CI_Model{

    //cek id dan password 
    function auth($username,$password){
        $query=$this->db->query("SELECT * FROM users WHERE User_Uname='$username' AND User_Pwd='$password' LIMIT 1");
        return $query;
    }
 
    //cek id dan password 
    function auth_member($username,$password){
        $query=$this->db->query("SELECT * FROM users WHERE User_Uname='$username' AND User_Pwd='$password' LIMIT 1");
        return $query;
    }
}